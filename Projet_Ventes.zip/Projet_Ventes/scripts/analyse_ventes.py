import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import os

def analyser_ventes():
    """Analyse les ventes et génère des rapports graphiques."""
    
    # Configuration des chemins
    db_path = Path(__file__).parent.parent / "data" / "ventes_magasin.db"
    report_dir = Path(__file__).parent.parent / "reports"
    os.makedirs(report_dir, exist_ok=True)
    
    if not db_path.exists():
        raise FileNotFoundError("Base de données introuvable. Exécutez d'abord create_db.py")

    try:
        # Connexion à la base de données
        conn = sqlite3.connect(db_path)
        
        # REQUÊTE CORRIGÉE (utilisation de prix_unitaire au lieu de prix)
        query = """
        SELECT 
            v.date, 
            p.nom as produit, 
            p.categorie, 
            p.prix_unitaire, 
            v.quantite, 
            v.montant, 
            c.nom as client, 
            c.ville
        FROM ventes v
        JOIN produits p ON v.produit_id = p.id
        JOIN clients c ON v.client_id = c.id
        """
        
        df = pd.read_sql(query, conn)
        
        # Conversion des dates
        df['date'] = pd.to_datetime(df['date'], format='%Y-%m-%d')
        df['mois'] = df['date'].dt.to_period('M')
        
        # 1. Statistiques de base
        print("\n=== STATISTIQUES GLOBALES ===")
        print(f"Période analysée : du {df['date'].min().date()} au {df['date'].max().date()}")
        print(f"Chiffre d'affaires total : {df['montant'].sum():.2f}€")
        print(f"Nombre total de ventes : {len(df)}")
        print(f"Panier moyen : {df['montant'].mean():.2f}€")
        print(f"Produits distincts vendus : {df['produit'].nunique()}")
        print(f"Clients uniques : {df['client'].nunique()}")

        # 2. Analyse par catégorie
        print("\n=== ANALYSE PAR CATÉGORIE ===")
        cat_stats = df.groupby('categorie').agg({
            'montant': ['sum', 'mean', 'count'],
            'quantite': 'sum'
        })
        print(cat_stats)

        # 3. Visualisations
        plt.style.use('seaborn')
        
        # Graphique 1: Évolution mensuelle du CA
        plt.figure(figsize=(12, 6))
        df.groupby('mois')['montant'].sum().plot(
            kind='bar', 
            color='royalblue',
            edgecolor='black'
        )
        plt.title("Évolution du chiffre d'affaires mensuel", fontsize=14)
        plt.xlabel("Mois")
        plt.ylabel("CA (€)")
        plt.grid(axis='y', alpha=0.3)
        plt.tight_layout()
        plt.savefig(report_dir / 'ca_mensuel.png', dpi=300)
        plt.close()
        
        # Graphique 2: Répartition par catégorie
        plt.figure(figsize=(10, 8))
        df.groupby('categorie')['montant'].sum().plot(
            kind='pie',
            autopct='%1.1f%%',
            explode=[0.05] * len(df['categorie'].unique()),
            shadow=True,
            startangle=90
        )
        plt.title("Répartition du CA par catégorie", fontsize=14)
        plt.ylabel("")
        plt.tight_layout()
        plt.savefig(report_dir / 'repartition_categories.png', dpi=300)
        plt.close()
        
        print(f"\nRapport généré avec succès dans : {report_dir}")

    except Exception as e:
        print(f"Erreur lors de l'analyse : {str(e)}")
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    analyser_ventes()
